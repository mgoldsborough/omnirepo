# Omnirepo Readiness Checklist

How ready is your organization for AI-powered orchestration?

Answer honestly. This isn't a test. It's a diagnostic.

---

## The Questions

### 1. Can AI read your company strategy right now?

Is your strategy written down in a file that AI can access? Or is it in someone's head, scattered across slides, or locked in a tool that doesn't export?

- [ ] Yes, it's in an accessible file
- [ ] Partially (some docs exist but incomplete)
- [ ] No, it's not documented

### 2. Is your brand voice documented somewhere AI can access?

When AI writes content for you, does it know how you sound? What words you use? What you avoid?

- [ ] Yes, we have a voice guide AI can read
- [ ] Partially (some guidelines exist)
- [ ] No, it's tribal knowledge

### 3. Do you have a single source of truth for pricing?

When pricing changes, how many places need to be updated? Is there one file that everything else references?

- [ ] Yes, one source that cascades
- [ ] Partially (some centralization)
- [ ] No, pricing lives in multiple places

### 4. When you ship a feature, how many manual steps until docs are updated?

Could AI draft the docs automatically by reading what changed? Or does someone need to context-switch and write from scratch?

- [ ] AI could do it (patterns exist)
- [ ] Some automation possible
- [ ] Fully manual process

### 5. Could a new teammate understand your org by reading files?

If someone joined tomorrow, could they read their way to understanding? Or would they need to ask people, attend meetings, absorb tribal knowledge?

- [ ] Yes, it's documented
- [ ] Partially (some docs exist)
- [ ] No, it requires asking people

### 6. Are your cross-functional workflows documented?

When you launch a campaign or ship a feature, is the process written down? Or does everyone just "know" what to do?

- [ ] Yes, workflows are documented
- [ ] Partially (some playbooks exist)
- [ ] No, it's tribal knowledge

### 7. Do different teams use consistent terminology?

Does engineering call it the same thing marketing calls it? Or do concepts have different names in different contexts?

- [ ] Yes, terminology is consistent
- [ ] Mostly (some inconsistencies)
- [ ] No, teams use different terms

### 8. Can you update positioning in one place and have it cascade?

If you refine how you describe your product, does that flow to docs, website, and content automatically? Or do you update each manually?

- [ ] Yes, changes cascade
- [ ] Partially (some automation)
- [ ] No, manual updates everywhere

### 9. Is your organizational knowledge exportable?

Could you move your company's knowledge out of your current tools if you needed to? Or is it locked in proprietary formats?

- [ ] Yes, everything exportable
- [ ] Mostly (some lock-in)
- [ ] No, significant lock-in

### 10. Is your organizational history preserved in version control?

Can AI understand not just what exists, but how it evolved and why? Are decisions traceable through commit history and change logs?

- [ ] Yes, everything is versioned with meaningful history
- [ ] Partially (code is versioned, docs aren't)
- [ ] No, changes happen without tracking

### 11. Could AI traverse from strategy to code to marketing in your current setup?

If AI wanted to understand your strategy, see how it's implemented in code, and how it's communicated in marketing, could it? Is there a path?

- [ ] Yes, it's all connected
- [ ] Partially (some gaps)
- [ ] No, they're siloed

---

## Scoring

Count your "Yes" answers:

| Score | Assessment | Recommendation |
|-------|------------|----------------|
| **0-3** | Fragmented | Start with `os/STRATEGY.md`. Get the basics out of heads and into files. |
| **4-6** | Partially Structured | Add domain context files (CLAUDE.md). Connect what exists. |
| **7-9** | Almost There | Build orchestration commands. Automate the cross-cutting workflows. |
| **10-11** | Omnirepo Ready | You're already there. Refine and compound. |

---

## Next Steps by Score

### If you scored 0-3: Start with Strategy

Your first file should be `os/STRATEGY.md`. Answer:
- What are you building?
- For whom?
- What are you NOT doing?

Get this out of heads and into a file. Everything else builds from here.

### If you scored 4-6: Add Domain Context

You have some structure. Now make it AI-readable:
- Add `CLAUDE.md` to each major domain
- Document patterns and conventions
- Create a root `CLAUDE.md` that maps the structure

### If you scored 7-9: Build Orchestration

Your structure exists. Now connect it:
- Create your first slash command (`/ship-feature`)
- Add `/extract-knowledge` to capture learnings
- Automate cross-functional workflows

### If you scored 10-11: Compound

You're already omnirepo. Now optimize:
- Add more orchestration commands
- Refine domain contexts based on usage
- Run `/extract-knowledge` religiously

---

## The Goal

An omnirepo isn't a destination. It's a practice.

The goal is: every session makes AI more useful. Every document compounds. Every workflow gets smoother.

Start where you are. Add structure. Watch it compound.

---

_From the [Omnirepo Manifesto](https://www.omnirepo.org)_
