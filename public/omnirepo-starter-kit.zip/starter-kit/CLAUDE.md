# [Company Name] Omnirepo

> Delete this section when you're done customizing.
> This is your root CLAUDE.md - the orchestration context that AI reads first.

## Overview

This repository contains everything [Company Name] produces:
- Strategy and positioning (`os/`)
- Products and code (`apps/`)
- Marketing materials (`marketing/`)
- Documentation (`docs/`)
- Websites (`websites/`)

## Directory Structure

| Path | Description | Has Context |
|------|-------------|-------------|
| `os/` | Company operating system (strategy, positioning, product) | See `os/` |
| `apps/` | Product code | Per-app CLAUDE.md |
| `marketing/` | GTM, brand voice, content | Yes |
| `docs/` | Product documentation | Yes |
| `websites/` | Marketing sites | Per-site |

## Cross-Repository Patterns

<!-- Describe how concepts map across your systems -->
<!-- Example: A "feature" in apps/ becomes a "capability" in docs/ and a "benefit" in marketing/ -->

## Working in This Repo

When making changes:
1. Read the relevant domain's CLAUDE.md for context
2. Reference `os/POSITIONING.md` for messaging alignment
3. Reference `marketing/BRAND_VOICE.md` for tone

## Key Commands

<!-- List your slash commands here as you build them -->
<!-- Example: /ship-feature, /update-pricing, /weekly-review -->

## Sources of Truth

| Concept | Location | Referenced By |
|---------|----------|---------------|
| Company strategy | `os/STRATEGY.md` | Everything |
| Positioning | `os/POSITIONING.md` | Marketing, docs, websites |
| Brand voice | `marketing/BRAND_VOICE.md` | All content |
| Pricing | `os/PRICING.md` | Docs, websites, sales |

---

_This repo follows the [Omnirepo pattern](https://www.omnirepo.org)._
