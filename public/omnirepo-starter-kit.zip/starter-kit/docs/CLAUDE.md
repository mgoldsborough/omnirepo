# Documentation Context

> This file tells AI how to operate in the docs domain.

## Overview

Product documentation for [Product Name].

## Structure

```
docs/
├── CLAUDE.md           # This file
├── getting-started/    # Onboarding content
├── guides/             # How-to guides
├── reference/          # API/technical reference
└── concepts/           # Explanatory content
```

## Documentation Principles

1. **Lead with the outcome** - What will they be able to do?
2. **Show, don't tell** - Code examples over explanations
3. **One page, one purpose** - Don't mix concepts
4. **Link liberally** - Connect related content

## Before Writing Docs

1. Reference `../os/PRODUCT.md` for feature descriptions
2. Reference `../marketing/BRAND_VOICE.md` for tone
3. Check existing docs for patterns to follow

## Page Structure

Every doc page should have:
- Clear title (action-oriented for guides)
- Brief intro (1-2 sentences, what and why)
- Prerequisites (if applicable)
- Steps or content
- Next steps (what to do after)

## Code Examples

- Always test code examples before publishing
- Include comments for non-obvious parts
- Show complete, runnable examples when possible

## Verification

Before publishing:
- [ ] Links work
- [ ] Code examples run
- [ ] Consistent with product behavior
- [ ] Follows voice guidelines
