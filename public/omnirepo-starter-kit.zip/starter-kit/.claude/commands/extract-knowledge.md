# /extract-knowledge

Extract learnings from the current session and update the omnirepo's knowledge base.

Run this before signing off or when context is about to be lost.

## Usage

```
/extract-knowledge
```

## Why This Exists

AI gets smarter over time, but only if knowledge persists. This command captures:
- Decisions made during the session
- New patterns discovered
- Context that future sessions will need
- Updates to existing documentation

Without this, every session starts from scratch. With this, the omnirepo compounds.

## What This Command Does

1. **Review the session**
   - What problems were solved?
   - What decisions were made (and why)?
   - What new patterns or conventions emerged?
   - What would be useful to know next time?

2. **Identify knowledge to capture**
   - New beliefs or positions to add to `os/` or beliefs docs
   - Process improvements to add to CLAUDE.md files
   - Patterns worth documenting
   - Terminology decisions
   - Architectural choices

3. **Update the omnirepo**
   - Add learnings to relevant CLAUDE.md files
   - Update strategy/positioning docs if views evolved
   - Add new templates if patterns emerged
   - Update checklists or playbooks

4. **Create session summary**
   - What was accomplished
   - What knowledge was extracted
   - What to pick up next time

## What to Look For

### Strategy & Positioning
- Did our understanding of the customer evolve?
- Did we make positioning decisions?
- Did we clarify what we do/don't do?

### Patterns & Conventions
- Did we establish a new pattern?
- Did we make a style/convention decision?
- Did we find a better way to do something?

### Domain Knowledge
- Did we learn something about a specific domain?
- Should a CLAUDE.md file be updated?
- Are there new "how we do X" decisions?

### Content & Voice
- Did we refine how we talk about something?
- Are there new terms or phrasings to capture?
- Did beliefs or positions evolve?

## Output Format

```markdown
## Session Knowledge Extract

### Session Summary
[What was accomplished]

### Knowledge Captured

#### Added to [file]
- [What was added and why]

#### Updated [file]
- [What changed and why]

### For Next Session
- [What to pick up]
- [Open questions]
```

## Example Extractions

**After a strategy session:**
> Updated `os/STRATEGY.md` with clearer "what we don't do" section.
> Added new belief #12 to `BELIEFS.md` about structure over process.

**After building a feature:**
> Added API pattern to `apps/api/CLAUDE.md` for how we handle auth.
> Updated `docs/CLAUDE.md` with new code example format.

**After writing content:**
> Added "omnirepo" to terminology in `os/POSITIONING.md`.
> Updated `marketing/BRAND_VOICE.md` with new phrases to use.

## The Compound Effect

Every `/extract-knowledge` run makes the omnirepo smarter:
- Future sessions have more context
- Patterns become explicit, not tribal
- Decisions persist beyond memory
- New team members inherit accumulated wisdom

This is how structure compounds over time.
