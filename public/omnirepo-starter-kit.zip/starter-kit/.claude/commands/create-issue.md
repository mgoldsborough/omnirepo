# /create-issue

Create an issue in the appropriate repo for work that's out of scope for the current session.

## Usage

```
/create-issue <repo> "<title>" [--label <label>] [--body "<description>"]
```

## Why This Exists

Not everything belongs in the current session. When you discover:
- A bug in another system
- A feature request for another team
- Technical debt worth tracking
- An idea that's out of scope

Don't context-switch. Don't lose the thread. Create a ticket and keep moving.

**Omnirepo for orchestration, tickets for handoffs.**

## What This Command Does

1. **Identifies the target repo** from the omnirepo structure
2. **Creates an issue** with appropriate labels and context
3. **Links back** to the current work for traceability
4. **Returns** the issue URL so you can reference it

## Supported Systems

| System | Command Pattern |
|--------|-----------------|
| GitHub | `gh issue create --repo <org>/<repo>` |
| Linear | `linear issue create --team <team>` |
| JIRA | `jira issue create --project <project>` |

## Examples

### Bug in API repo

```
/create-issue api "Auth token refresh fails silently" --label bug
```

Executes:
```bash
gh issue create --repo acme/api \
  --title "Auth token refresh fails silently" \
  --label "bug" \
  --body "Discovered during [current context].

         [Auto-generated description based on session context]

         ---
         Created via omnirepo handoff."
```

### Feature request for another team

```
/create-issue mobile "Add biometric auth support" --label enhancement
```

### Technical debt tracking

```
/create-issue api "Refactor auth middleware to support multiple providers" --label tech-debt
```

## Context Injection

The command automatically includes:
- What you were working on when you discovered this
- Any relevant code references
- Link back to the session/PR if applicable

This ensures the person picking up the issue has context without you having to write it all out.

## Repo Mapping

Configure repo shortcuts in your root `CLAUDE.md`:

```markdown
## Issue Repos

| Shortcut | Full Repo |
|----------|-----------|
| api | acme/api-server |
| web | acme/web-client |
| mobile | acme/mobile-app |
| docs | acme/documentation |
```

## The Handoff Pattern

```
You (working on feature X)
    │
    ├── Discover bug in system Y
    │
    ├── /create-issue Y "bug description"
    │       │
    │       └── Issue created, URL returned
    │
    └── Continue working on feature X
```

No context switch. No lost work. Clean handoff.
