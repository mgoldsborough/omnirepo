# /ship-feature

Ship a feature with aligned docs, blog post, and social content.

## Usage

```
/ship-feature "Feature Name" [--blog] [--social]
```

## What This Command Does

1. **Understand the change**
   - Read recent commits or diff to understand what was built
   - Identify the user-facing impact

2. **Update documentation**
   - Create or update relevant doc pages in `docs/`
   - Follow patterns in `docs/CLAUDE.md`
   - Update changelog if it exists

3. **Draft blog post** (if --blog)
   - Read `os/POSITIONING.md` for framing
   - Read `marketing/BRAND_VOICE.md` for tone
   - Create draft in `marketing/content/drafts/`
   - Focus on the "why" and user benefit, not just "what"

4. **Draft social posts** (if --social)
   - Create LinkedIn post draft
   - Create Twitter/X thread draft
   - Align with any active campaigns in `marketing/campaigns/`

5. **Report**
   - Summarize what was created/updated
   - List files changed
   - Note any manual steps needed

## Context to Read

Before executing, read:
- `os/POSITIONING.md` - How we frame things
- `marketing/BRAND_VOICE.md` - How we sound
- `docs/CLAUDE.md` - Doc patterns
- Recent git history - What changed

## Example

```
/ship-feature "Analytics Dashboard" --blog --social
```

Creates:
- `docs/guides/analytics-dashboard.md`
- `marketing/content/drafts/introducing-analytics-dashboard.md`
- Social post drafts in output

## Notes

- All content should use consistent terminology from `os/POSITIONING.md`
- Blog posts should lead with benefit, not feature
- Social posts should fit platform conventions (LinkedIn: longer, Twitter: punchy)
