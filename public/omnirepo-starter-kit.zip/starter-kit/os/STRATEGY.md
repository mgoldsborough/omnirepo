# Strategy

> This is your company's north star. Everything else references this document.
> Delete the prompts once you've filled them in.

## The Bet

<!-- What are you betting on? What change in the world are you positioned for? -->
<!-- Example: "AI will handle orchestration, humans will handle judgment." -->

## The Customer

<!-- Who exactly are you building for? Be specific. -->
<!-- Example: "Technical founders at seed-stage startups who are building AI-native products." -->

### They are...
<!-- Demographics, role, situation -->

### They struggle with...
<!-- The pain points you solve -->

### They want...
<!-- The outcome they're seeking -->

## What We Build

<!-- One sentence: what do you actually make? -->

## What We Don't Do

<!-- This is just as important. What are you explicitly NOT doing? -->
<!-- Example: "We don't do services. We don't build vertical solutions. We don't chase enterprise deals." -->

-
-
-

## How We Win

<!-- What's your unfair advantage? Why you and not someone else? -->

## Key Metrics

<!-- What numbers tell you if you're winning? -->

| Metric | Current | Target |
|--------|---------|--------|
| | | |

---

_Last updated: [date]_
