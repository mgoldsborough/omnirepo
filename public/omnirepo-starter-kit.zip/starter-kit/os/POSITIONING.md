# Positioning

> How you talk about yourself. This document should be referenced by all marketing, docs, and external content.
> Delete the prompts once you've filled them in.

## One-Liner

<!-- Complete this sentence: "[Company] helps [customer] [achieve outcome] by [how]." -->

## Tagline

<!-- 3-5 words. What you'd put on a billboard. -->

## Elevator Pitch

<!-- 30 seconds. What do you say when someone asks "what do you do?" -->

## The Category

<!-- What category do you compete in? Or are you creating a new one? -->
<!-- Example: "AI-native automation platform" or "Agent orchestration" -->

## Key Differentiators

<!-- What makes you different from alternatives? Be specific. -->

1. **[Differentiator 1]:**
2. **[Differentiator 2]:**
3. **[Differentiator 3]:**

## Positioning Statement

<!-- For [target customer] who [need], [Product] is a [category] that [key benefit]. Unlike [alternatives], we [key differentiator]. -->

## Messaging Pillars

<!-- The 3-4 themes you consistently communicate -->

### Pillar 1: [Name]
<!-- Key message and supporting points -->

### Pillar 2: [Name]
<!-- Key message and supporting points -->

### Pillar 3: [Name]
<!-- Key message and supporting points -->

## Words We Use

<!-- Terminology that's distinctly yours -->

| Concept | Our Term | Not This |
|---------|----------|----------|
| | | |

## Words We Avoid

<!-- Terms that don't fit your brand -->

- "Leverage" (use "use")
- "Utilize" (use "use")
- "Solution" (be specific)
-

## Competitive Positioning

<!-- How you position against alternatives -->

| Alternative | Their Angle | Our Angle |
|-------------|-------------|-----------|
| | | |

---

_Last updated: [date]_
