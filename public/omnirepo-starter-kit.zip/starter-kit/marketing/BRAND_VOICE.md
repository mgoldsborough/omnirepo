# Brand Voice Guide

> How [Company] sounds. Reference this for all external content.
> Delete the prompts once you've filled them in.

## Voice Statement

<!-- One paragraph describing how your company sounds -->
<!-- Example: "[Company] writes as a seasoned expert who's genuinely excited to share knowledge. The tone is confident without being arrogant, technical without being intimidating." -->

## Voice Characteristics

### We Are

- **[Trait 1]:** <!-- e.g., "Direct: We get to the point. No corporate fluff." -->
- **[Trait 2]:** <!-- e.g., "Helpful: We genuinely want readers to succeed." -->
- **[Trait 3]:** <!-- e.g., "Technical but accessible: We use precise terms but explain them." -->
- **[Trait 4]:**

### We're Not

- **[Anti-trait 1]:** <!-- e.g., "Corporate: No 'synergy' or 'leverage' or 'solutions'" -->
- **[Anti-trait 2]:** <!-- e.g., "Condescending: We don't talk down to anyone" -->
- **[Anti-trait 3]:**

## Tone by Context

| Context | Tone | Example |
|---------|------|---------|
| Product docs | Precise, helpful | "Run this command to..." |
| Blog posts | Conversational, personal | "I've been thinking about..." |
| Error messages | Friendly, actionable | "That didn't work. Try..." |
| Marketing | Confident, benefit-focused | "Ship faster without..." |

## Writing Style

### Sentence Structure
- Mix short and medium sentences
- Lead with the benefit or action
- Active voice, not passive

### Word Choice
- Use contractions (we're, don't, isn't)
- Strong verbs over weak ones
- Specific over vague

### Formatting
- Short paragraphs (2-4 sentences)
- Use headers to break up content
- Bullet points for lists of 3+

## Words We Use

<!-- Your vocabulary. Terms that feel distinctly like your brand. -->

-
-
-

## Words We Avoid

<!-- Terms that don't fit your voice -->

| Avoid | Use Instead |
|-------|-------------|
| Leverage | Use |
| Utilize | Use |
| Solution | [be specific] |
| Robust | [be specific] |
| Seamless | [be specific] |

## Example: Before & After

**Before (generic):**
> "Our solution leverages cutting-edge AI technology to provide robust automation capabilities for enterprise customers."

**After (on-brand):**
> "We help teams automate the boring stuff so they can focus on work that matters."

## Quick Checklist

Before publishing, ask:
- [ ] Would I say this to a colleague over coffee?
- [ ] Did I lead with the benefit?
- [ ] Is it active voice?
- [ ] Would a smart non-technical person understand this?
- [ ] Does it sound like us, not a corporation?

---

_Last updated: [date]_
