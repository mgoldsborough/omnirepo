# Marketing Context

> This file tells AI how to operate in the marketing domain.

## Overview

This directory contains go-to-market materials: brand voice, content, campaigns, and collateral.

## Key Files

| File | Purpose | When to Reference |
|------|---------|-------------------|
| `BRAND_VOICE.md` | How we sound | Any external content |
| `content/` | Blog posts, case studies | Creating new content |
| `campaigns/` | Active marketing campaigns | Social posts, timing |

## Content Guidelines

### Before Writing Any Content

1. Read `BRAND_VOICE.md` for tone and style
2. Reference `../os/POSITIONING.md` for messaging alignment
3. Check `campaigns/` for active themes to align with

### Content Types

| Type | Location | Template |
|------|----------|----------|
| Blog posts | `content/drafts/` | `content/templates/blog-post.md` |
| Case studies | `content/drafts/` | `content/templates/case-study.md` |
| Social posts | `campaigns/social/` | Per-platform in campaign files |

## Voice Quick Reference

<!-- Pull key points from BRAND_VOICE.md for quick reference -->

**We are:**
- Conversational but knowledgeable
- Direct but helpful
- Technical but accessible

**We're not:**
- Corporate or formal
- Condescending or elitist
- Verbose or meandering

## Verification

Before publishing any content:
- [ ] Aligns with current positioning
- [ ] Follows brand voice guidelines
- [ ] Links to relevant resources
- [ ] No messaging conflicts with active campaigns
